- Notre rapport fait 52 pages. (25 pages sans annexes au lieu de 15 comme demandé) 
Nous avons préféré faire des sauts de page pour rendre le rapport plus lisible et l'avons étoffé d'images pour le rendre plus compréhensible. 



- Pour tester notre intelligence artificielle, 
veuillez copier les dossiers 'Test' et 'IA54' qui contiennent les cartes de test, dans l'emplacement suivant :

'\ipseity_1-2-2_kernel_sc\app\IpseityProject\data\Scenarios\Delirium2\Lauri Fabrice'.

Les scénarios fournis avec 'BoulderDash' ne fonctionnent pas. Les cartes sont trop grandes.